#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 15:37:42 2020

@author: toinon
"""

import numpy as np
import pandas as pd
import csv
import math

"""Function to extract fixations / saccades"""

def fixation_detection(gaze_data_file, fix_file, missing=0.0, maxdist=75, mindur=50) :
    """Detects fixations, defined as consecutive samples with an inter-sample distance of less than a set amount of pixels (disregarding missing data)
    Parameters
    ----------
    x : array
        Gaze x positions
    y : array
        Gaze y positions
    time : array
        Timestamps
    missing : float
        Value to be used for missing data (default = 0.0)
    maxdist : int
        Maximal inter sample distance in pixels (default = 25)
    mindur : int
        Minimal duration of a fixation in milliseconds; detected fixation cadidates will be disregarded if they are below this duration (default = 100)
    Returns
    -------
    Sfix : list of lists
        Each containing [starttime]
    Efix : list of lists
        Each containing [starttime, endtime, duration, endx, endy]
    """
    df_gazedata = pd.read_csv(gaze_data_file, sep=',')
    x = df_gazedata.x
    y = df_gazedata.y
    time = df_gazedata.timestamp

    # empty list to contain data
    Sfix = []
    Efix = []

    # loop through all coordinates
    si = 0
    fixstart = False
    for i in range(1,len(x)):
        # calculate Euclidean distance from the current fixation coordinate
        # to the next coordinate
        dist = ((x[si]-x[i])**2 + (y[si]-y[i])**2)**0.5
        # check if the next coordinate is below maximal distance
        if dist <= maxdist and not fixstart:
            # start a new fixation
            si = 0 + i
            fixstart = True
            Sfix.append([time[i]])
        elif dist > maxdist and fixstart:
            # end the current fixation
            fixstart = False
            # only store the fixation if the duration is ok
            if time[i-1]-Sfix[-1][0] >= mindur:
                Efix.append([Sfix[-1][0], time[i-1], time[i-1]-Sfix[-1][0], x[si], y[si]])
            # delete the last fixation start if it was too short
            else:
                Sfix.pop(-1)
            si = 0 + i
        elif not fixstart:
            si += 1
    
    np.savetxt(fix_file, Efix, delimiter=",")
    #return Sfix, Efix



"""Function to extract fixation information from all eye movements
Input: data_filename with original fixations from dataset info
Output : one csv per observer with 4 columns (Idx, Duration (s), PosX (px), PosY (px), Time), each line is a fixation"""

def extractFixationFeatures(data_filename, fix_filename) :
    #load data from original dataset
    csv_data = np.genfromtxt(data_filename, delimiter=',')

    #create a new dataframe for fixations
    df_fix = pd.DataFrame(data=np.zeros([csv_data.shape[0],5]), columns=['Idx','Duration','PosX','PosY','Time'])

    #transform fixations in target format _ one file per user
    df_fix.Idx = np.arange(csv_data.shape[0])
    df_fix.Duration = csv_data[:,2]
    df_fix.PosX = csv_data[:,3]
    df_fix.PosY = csv_data[:,4]
    df_fix.Time = csv_data[:,0]

    df_fix.to_csv(fix_filename, index=False) 
        
    

"""Function to extract saccade information from all eye movements
Input: fix_filename with fixation info
Output : 2D array with 6 columns (Idx, Amplitude (px), Absolute Angle (°), 
                                      Relative Angle (°), Time, Duration)
        each line is a saccade"""
            
def extractSaccadeFeatures(fix_filename, sacc_filename) : 
    #load fixations 
    csv_fix = pd.read_csv(fix_filename, sep=',')
    df_fix = pd.DataFrame(csv_fix)

    #list containing the beginning/ending index of each observer
    idx_list = df_fix[df_fix.Idx == 0].index.tolist()
    idx_list.append(df_fix.shape[0])


    sacc_array = np.empty((0,8))

    #saccadic features
    for i in range(len(idx_list)-1) :
        current_idx = idx_list[i]
        next_idx = idx_list[i+1]

        temp_array = np.zeros((next_idx - current_idx - 1, 8))
        temp_array[:,0] = df_fix.Idx[current_idx : next_idx - 1]

        prev_angle = 0

        for j in range(current_idx, next_idx - 1) :
            sacc_vector = [ df_fix.PosX[j+1] - df_fix.PosX[j] , df_fix.PosY[j+1] - df_fix.PosY[j] ]
            sacc_norm = np.sqrt( sacc_vector[0]**2 + sacc_vector[1]**2 )
            sacc_cos = np.dot(sacc_vector,[1,0]) / sacc_norm   

            absolute_angle_360 = np.rad2deg(np.arccos(sacc_cos)) 
            if (sacc_vector[1] < 0) :
                absolute_angle_360 = 360 - absolute_angle_360
   
            relative_angle_360 = (absolute_angle_360 - prev_angle) % 360
            prev_angle = absolute_angle_360


            if absolute_angle_360 >180 : 
                absolute_angle_180 = 360 - absolute_angle_360
            else : 
                absolute_angle_180 = absolute_angle_360

            if relative_angle_360 >180 : 
                relative_angle_180 = 360 - relative_angle_360
            else : 
                relative_angle_180 = relative_angle_360



            temp_array[j - current_idx,1] = sacc_norm
            temp_array[j - current_idx,2] = absolute_angle_360
            temp_array[j - current_idx,3] = relative_angle_360
            temp_array[j - current_idx,4] = df_fix.Time[j]+df_fix.Duration[j]
            temp_array[j - current_idx,5] = df_fix.Time[j+1] - (df_fix.Time[j]+df_fix.Duration[j])
            temp_array[j - current_idx,6] = absolute_angle_180
            temp_array[j - current_idx,7] = relative_angle_180


        sacc_array = np.append(sacc_array,temp_array, axis=0)

  
    #save dataframe
    df_sacc = pd.DataFrame(data=sacc_array, columns=['Idx','Amplitude','Abs Ang 360','Rel Ang 360','Time','Duration','Abs Ang 180','Rel Ang 180'])
    df_sacc.to_csv(sacc_filename, index=False) 



    
    



    
    

"""Extraction de tous les cas"""
dir_name_data = 'dataset_normalised_5mins/'
dir_extractedFix = 'Fixations/'
dir_name_fix = 'Fixations_Features/'
dir_name_sacc = 'Saccades_Features/'
nb_observer = 24

for i in range(1, 10) :
    fixation_detection(dir_name_data+'P0'+str(i)+'_WATCH.csv', dir_extractedFix+'P0'+str(i)+'_WATCH.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_WATCH.csv', dir_name_fix+'P0'+str(i)+'_WATCH.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_WATCH.csv', dir_name_sacc+'P0'+str(i)+'_WATCH.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_BROWSE.csv', dir_extractedFix+'P0'+str(i)+'_BROWSE.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_BROWSE.csv', dir_name_fix+'P0'+str(i)+'_BROWSE.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_BROWSE.csv', dir_name_sacc+'P0'+str(i)+'_BROWSE.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_DEBUG.csv', dir_extractedFix+'P0'+str(i)+'_DEBUG.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_DEBUG.csv', dir_name_fix+'P0'+str(i)+'_DEBUG.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_DEBUG.csv', dir_name_sacc+'P0'+str(i)+'_DEBUG.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_INTERPRET.csv', dir_extractedFix+'P0'+str(i)+'_INTERPRET.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_INTERPRET.csv', dir_name_fix+'P0'+str(i)+'_INTERPRET.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_INTERPRET.csv', dir_name_sacc+'P0'+str(i)+'_INTERPRET.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_PLAY.csv', dir_extractedFix+'P0'+str(i)+'_PLAY.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_PLAY.csv', dir_name_fix+'P0'+str(i)+'_PLAY.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_PLAY.csv', dir_name_sacc+'P0'+str(i)+'_PLAY.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_READ.csv', dir_extractedFix+'P0'+str(i)+'_READ.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_READ.csv', dir_name_fix+'P0'+str(i)+'_READ.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_READ.csv', dir_name_sacc+'P0'+str(i)+'_READ.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_SEARCH.csv', dir_extractedFix+'P0'+str(i)+'_SEARCH.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_SEARCH.csv', dir_name_fix+'P0'+str(i)+'_SEARCH.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_SEARCH.csv', dir_name_sacc+'P0'+str(i)+'_SEARCH.csv')

    fixation_detection(dir_name_data+'P0'+str(i)+'_WRITE.csv', dir_extractedFix+'P0'+str(i)+'_WRITE.csv')
    extractFixationFeatures(dir_extractedFix+'P0'+str(i)+'_WRITE.csv', dir_name_fix+'P0'+str(i)+'_WRITE.csv')
    extractSaccadeFeatures(dir_name_fix+'P0'+str(i)+'_WRITE.csv', dir_name_sacc+'P0'+str(i)+'_WRITE.csv')

for i in range(10, 25) :
    fixation_detection(dir_name_data+'P'+str(i)+'_WATCH.csv', dir_extractedFix+'P'+str(i)+'_WATCH.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_WATCH.csv', dir_name_fix+'P'+str(i)+'_WATCH.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_WATCH.csv', dir_name_sacc+'P'+str(i)+'_WATCH.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_BROWSE.csv',dir_extractedFix+'P'+str(i)+'_BROWSE.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_BROWSE.csv', dir_name_fix+'P'+str(i)+'_BROWSE.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_BROWSE.csv', dir_name_sacc+'P'+str(i)+'_BROWSE.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_DEBUG.csv', dir_extractedFix+'P'+str(i)+'_DEBUG.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_DEBUG.csv', dir_name_fix+'P'+str(i)+'_DEBUG.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_DEBUG.csv', dir_name_sacc+'P'+str(i)+'_DEBUG.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_INTERPRET.csv', dir_extractedFix+'P'+str(i)+'_INTERPRET.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_INTERPRET.csv', dir_name_fix+'P'+str(i)+'_INTERPRET.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_INTERPRET.csv', dir_name_sacc+'P'+str(i)+'_INTERPRET.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_PLAY.csv', dir_extractedFix+'P'+str(i)+'_PLAY.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_PLAY.csv', dir_name_fix+'P'+str(i)+'_PLAY.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_PLAY.csv', dir_name_sacc+'P'+str(i)+'_PLAY.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_READ.csv', dir_extractedFix+'P'+str(i)+'_READ.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_READ.csv', dir_name_fix+'P'+str(i)+'_READ.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_READ.csv', dir_name_sacc+'P'+str(i)+'_READ.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_SEARCH.csv', dir_extractedFix+'P'+str(i)+'_SEARCH.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_SEARCH.csv', dir_name_fix+'P'+str(i)+'_SEARCH.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_SEARCH.csv', dir_name_sacc+'P'+str(i)+'_SEARCH.csv')

    fixation_detection(dir_name_data+'P'+str(i)+'_WRITE.csv', dir_extractedFix+'P'+str(i)+'_WRITE.csv')
    extractFixationFeatures(dir_extractedFix+'P'+str(i)+'_WRITE.csv', dir_name_fix+'P'+str(i)+'_WRITE.csv')
    extractSaccadeFeatures(dir_name_fix+'P'+str(i)+'_WRITE.csv', dir_name_sacc+'P'+str(i)+'_WRITE.csv')