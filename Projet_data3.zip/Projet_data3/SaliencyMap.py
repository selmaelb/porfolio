#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 10:55:25 2020

@author: toinon
"""

"""
Function to compute a saliency map from a list of fixation points 
Inputs: 
    - fixations_features: 
    - screenX: width of the screen in pixels
    - screenY: height of the screen in pixels
    - sigma : sigma of the applied gaussian in pixels
Output : saliency map (2D array)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage.filters import gaussian_filter
import pandas as pd




def compute_saliency_map(fixations_features, screenX, screenY, sigma) : 
    # PARSE GAZE DATA
    csv_fix = pd.read_csv(fixations_features, sep=',')
    df_fix = pd.DataFrame(csv_fix)
    
    #Create a 2D map with zeros
    saliency_map = np.zeros([screenY,screenX])
    
    #Increment by one all the pixels with a fixation
    for row in df_fix.iterrows():
    
        if (0<=row[1].PosY<1080 and 0<=row[1].PosX<1920) :
            saliency_map[int(row[1].PosY),int(row[1].PosX)] = saliency_map[int(row[1].PosY),int(row[1].PosX)] + 1
    
    #Normalization (max=1)
    saliency_map = saliency_map / np.max(saliency_map)
    
    #Gaussian filter
    saliency_map = gaussian_filter(saliency_map,sigma)
    
    return saliency_map
    
        
def plot_saliency_map(sal_map) :
    plt.figure()
    plt.gray()
    plt.imshow(sal_map)
    plt.show()
    

def save_saliency_map(filename, sal_map) :
    plt.gray()
    plt.imsave(filename,sal_map)



s = compute_saliency_map('Fixations_Features/P01_WATCH.csv', 1920, 1080, 75)
plot_saliency_map(s)
