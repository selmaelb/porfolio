#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 14:53:07 2021

@author: vigier-t2 (from the PyGazeAnalysis library )

"""

import numpy as np
import pandas as pd
import matplotlib
from matplotlib import pyplot as plt
import matplotlib.patches as patches

def draw_gazedata(ax, gazedatafile, dispsize, imagefile=None):
    # PARSE GAZE DATA
    csv_gaze = pd.read_csv(gazedatafile, sep=',')
    df_gaze = pd.DataFrame(csv_gaze)

    if (imagefile is not None) :
        # DRAW IMAGE
        image = plt.imread(imagefile)
        background = np.zeros((dispsize[0],dispsize[1],image.shape[2]))

        startX = int((dispsize[0] - image.shape[0])/2)
        startY = int((dispsize[1] - image.shape[1])/2)
    
        background[startX:startX+image.shape[0], startY:startY+image.shape[1]] = image

        #Add image
        ax.imshow(background)

    # draw gaze points
    ax.scatter(df_gaze.x, df_gaze.y, s=20,c='b', marker='+')


def draw_fixations(ax, fixations, dispsize, imagefile=None, durationsize=True, timecolour=True, line=True, alpha=0.5):
    
    """Draws circles on the fixation locations, optionally on top of an image,
    with optional weigthing of the duration for circle size and colour
    
    arguments
    
    ax               -    axes (matplotlib) on which fixations are drawn 
    
    
    fixations        -    a list of fixation ending events
                   

    dispsize        -    tuple or list indicating the size of the display,
                    e.g. (1024,768)
    
    keyword arguments
    
    imagefile        -    full path to an image file over which the heatmap
                    is to be laid, or None for no image; NOTE: the image
                    may be smaller than the display size, the function
                    assumes that the image was presented at the centre of
                    the display (default = None)

    durationsize    -    Boolean indicating whether the fixation duration is
                    to be taken into account as a weight for the circle
                    size; longer duration = bigger (default = True)

    timecolour      -    Boolean indicating whether the fixation Idx is
                    to be taken into account as a weight for the circle
                    colour; longer duration = hotter (default = True)

    line            -   Boolean indicating if the fixations are linked 

    alpha           -    float between 0 and 1, indicating the transparancy of
                    the heatmap, where 0 is completely transparant and 1
                    is completely untransparant (default = 0.5)
 
    
    returns
    
    fig            -    a matplotlib.pyplot Figure instance, containing the
                    fixations
    """



    # PARSE FIXATIONS
    csv_fix = pd.read_csv(fixations, sep=',')
    df_fix = pd.DataFrame(csv_fix)
        
    # DRAW IMAGE
    if (imagefile is not None) :
        image = plt.imread(imagefile)
        background = np.zeros((dispsize[0],dispsize[1],image.shape[2]))
        
        startX = int((dispsize[0] - image.shape[0])/2)
        startY = int((dispsize[1] - image.shape[1])/2)
    
        background[startX:startX+image.shape[0], startY:startY+image.shape[1]] = image

        #Add image
        ax.imshow(background)

    # DRAW FIXATIONS
    # CIRCLES
    # duration weigths
    if durationsize:
        siz = df_fix.Duration
       
    else:
        siz = np.median(df_fix.Duration)/5

    if timecolour:
        col = np.arange(len(df_fix.Idx))
    else:
        col = 'r'

     # draw circles
    ax.scatter(df_fix.PosX,df_fix.PosY, s=siz,c=col, marker='o',cmap='jet',alpha=alpha)
    ax.scatter(np.mean(df_fix.PosX),np.mean(df_fix.PosY),s=50,c='b', marker='X')

    
    #draw lines
    if line : 
       for i in range(len(df_fix.Idx)-1) :
            if(df_fix.Idx[i+1] != 0) : 
                ax.arrow(df_fix.PosX[i], df_fix.PosY[i], df_fix.PosX[i+1]-df_fix.PosX[i], df_fix.PosY[i+1]-df_fix.PosY[i], width=0.02,color='pink',head_length=0.0,head_width=0.0)





def draw_saccades(ax, fixationfile, dispsize, imagefile=None):
    # PARSE FIXATIONS
    csv_fix = pd.read_csv(fixationfile, sep=',')
    df_fix = pd.DataFrame(csv_fix)
        
    # DRAW IMAGE
    if (imagefile is not None) :
        image = plt.imread(imagefile)
        background = np.zeros((dispsize[0],dispsize[1],image.shape[2]))
    
        startX = int((dispsize[0] - image.shape[0])/2)
        startY = int((dispsize[1] - image.shape[1])/2)
   
        background[startX:startX+image.shape[0], startY:startY+image.shape[1]] = image

        #Add image
        ax.imshow(background)
    
    #DRAW SACCADES (as arrows)
    for i in range(len(df_fix.Idx)-1) :
        if(df_fix.Idx[i+1] != 0) : 
            ax.arrow(df_fix.PosX[i], df_fix.PosY[i], df_fix.PosX[i+1]-df_fix.PosX[i], df_fix.PosY[i+1]-df_fix.PosY[i], width=0.02,color='pink',head_length=20.0,head_width=20.0)



'''TEST'''
# Create figure and axes
fig, ax = plt.subplots()

draw_gazedata(ax, 'dataset_normalised_5mins/P01_WATCH.csv', dispsize=None, imagefile=None)
draw_fixations(ax, 'Fixations_Features/P01_WATCH.csv', (1080,1920), None, durationsize=False, timecolour=False, line=True, alpha=0.5)
#draw_saccades(ax, 'fix.csv', (1980,1080), None)


plt.show()
