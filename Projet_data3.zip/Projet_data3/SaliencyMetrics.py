#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Tue Apr 21 14:27:59 2020

@author: toinon
"""

import numpy as np


"""Function to compute KLD dissimilarity metric between 2 saliency maps
Inputs: map1 and map2, 2d array
Output: KLD value"""

def KLD(map1, map2) : 
    #sum of each map must be 1
    if (np.sum(map1) != 0) : 
        map1 = map1 / np.sum(map1)
        print(np.sum(map1))
        
    if (np.sum(map2) != 0) : 
        map2 = map2 / np.sum(map2)
        print(np.sum(map1))
    #epsilon value to avoid division by 0 and log(0)
    eps = 1e-16
    
    #KLD is not symetric: mean of KLD(1,2) and KLD(2,1)
    KLD1 = np.sum(np.sum(map2 * np.log(eps + map2/(map1+eps))));
    KLD2 = np.sum(np.sum(map1 * np.log(eps + map1/(map2+eps))));
    KLD = (KLD1+KLD2) / 2
    
    return KLD


"""Function to compute correlation coefficient between 2 saliency maps
Inputs: map1 and map2, 2d array
Output: correlation coefficient"""

def corr2D(map1, map2) :
    # mean of each map
    M1 = np.mean(map1)
    M2 = np.mean(map2)
    
    #coefficient
    corr_coeff = (np.sum((map1-M1)*(map2-M2))) / np.sqrt( np.sum((map1-M1)**2) * np.sum((map2-M2)**2) )
    
    return corr_coeff
    

'''
#Test
import matplotlib.pyplot as plt

#read saliency map1 as a grey image
map1 = plt.imread('ASD_FixMaps/1_s.png')
print(map1)
map1 = map1[:,:,0] 


#read saliency map1 as a grey image
map2 = plt.imread('TD_FixMaps/1_s.png')
map2 = map2[:,:,0]

#KLD
KLDvalue = KLD(map1,map2)
print(KLDvalue)

#correlation
corr = corr2D(map1,map2)
print(corr)
'''